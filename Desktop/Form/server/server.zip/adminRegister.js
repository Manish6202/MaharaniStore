// adminRegister.js
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
require("dotenv").config();
const Admin = require("./models/Admin");

const registerAdmin = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URL);
    console.log(" Connected to DB");

    const name = "Super Admin";
    const email = "admin@example.com";
    const password = "admin123"; // plain password

    const existing = await Admin.findOne({ email });
    if (existing) {
      console.log("Admin already exists");
      return process.exit(0);
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newAdmin = new Admin({ name, email, password: hashedPassword });
    await newAdmin.save();

    console.log("Admin created:", { name, email });
    process.exit(0);
  } catch (err) {
    console.error("Error creating admin:", err);
    process.exit(1);
  }
};

registerAdmin();
